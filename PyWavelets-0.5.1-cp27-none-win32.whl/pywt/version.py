
# THIS FILE IS GENERATED FROM PYWAVELETS SETUP.PY
short_version = '0.5.1'
version = '0.5.1'
full_version = '0.5.1'
git_revision = '03c909c021456c1d7b86dd5cc63bcfd926f6ca34'
release = True

if not release:
    version = full_version
